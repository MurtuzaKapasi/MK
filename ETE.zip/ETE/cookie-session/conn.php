<?php

$conn = mysqli_connect("localhost", "root", "", "murtuza") or die("Connection Error");

?>